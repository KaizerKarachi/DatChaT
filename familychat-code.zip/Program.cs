using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;
using FamilyChat.Data;
using FamilyChat.Hubs;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<ChatDbContext>();
builder.Services.AddSignalR();

var app = builder.Build();

// Статические файлы из wwwroot
app.UseStaticFiles();

// Статические файлы из uploads
var uploadsPath = Path.Combine(Directory.GetCurrentDirectory(), "uploads");
if (!Directory.Exists(uploadsPath))
{
    Directory.CreateDirectory(uploadsPath);
}

app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(uploadsPath),
    RequestPath = "/uploads"
});

// Главная страница - отдаем index.html
app.MapGet("/", async context =>
{
    var indexPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "index.html");
    if (File.Exists(indexPath))
    {
        context.Response.ContentType = "text/html";
        await context.Response.SendFileAsync(indexPath);
    }
    else
    {
        context.Response.StatusCode = 404;
        await context.Response.WriteAsync("index.html not found");
    }
});

// SignalR хаб
app.MapHub<ChatHub>("/chat");

// Endpoint для загрузки файлов
app.MapPost("/upload", async (HttpRequest request) =>
{
    var form = await request.ReadFormAsync();
    var file = form.Files.FirstOrDefault();
    
    if (file == null || file.Length == 0)
        return Results.BadRequest("Нет файла");
    
    var uploadsDir = Path.Combine(Directory.GetCurrentDirectory(), "uploads");
    if (!Directory.Exists(uploadsDir))
        Directory.CreateDirectory(uploadsDir);
    
    var fileName = $"{Guid.NewGuid()}_{file.FileName}";
    var filePath = Path.Combine(uploadsDir, fileName);
    
    using (var stream = new FileStream(filePath, FileMode.Create))
    {
        await file.CopyToAsync(stream);
    }
    
    var fileType = file.ContentType.StartsWith("image/") ? "image" : "file";
    
    return Results.Json(new { 
        fileName = file.FileName, 
        fileUrl = $"/uploads/{fileName}", 
        fileType = fileType 
    });
});

app.Run();
