using Microsoft.AspNetCore.SignalR;
using FamilyChat.Data;
using FamilyChat.Models;
using Microsoft.EntityFrameworkCore;

namespace FamilyChat.Hubs;

public class ChatHub : Hub
{
    private readonly ChatDbContext _db;
    private readonly ILogger<ChatHub> _logger;

    public ChatHub(ChatDbContext db, ILogger<ChatHub> logger)
    {
        _db = db;
        _logger = logger;
    }

    public async Task RegisterOrLogin(string nickname, string password)
    {
        if (string.IsNullOrWhiteSpace(nickname) || string.IsNullOrWhiteSpace(password))
            throw new HubException("Введите ник и пароль");

        if (!nickname.StartsWith('#')) nickname = "#" + nickname;

        var user = await _db.Users.FirstOrDefaultAsync(u => u.Nickname == nickname);

        if (user == null)
        {
            _logger.LogInformation($"[НОВЫЙ] Регистрация: {nickname}");
            user = new User
            {
                Nickname = nickname,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(password),
                IsApproved = true,
                IsAdmin = false,
                SessionToken = Guid.NewGuid().ToString()
            };
            _db.Users.Add(user);
        }
        else
        {
            if (!BCrypt.Net.BCrypt.Verify(password, user.PasswordHash))
                throw new HubException("Неверный пароль!");
            
            user.SessionToken = Guid.NewGuid().ToString();
        }

        await FinalizeLogin(user, true);
    }

    public async Task JoinByToken(string nickname, string sessionToken)
    {
        if (string.IsNullOrWhiteSpace(nickname) || string.IsNullOrWhiteSpace(sessionToken))
            throw new HubException("Неверные данные");

        if (!nickname.StartsWith('#')) nickname = "#" + nickname;

        var user = await _db.Users.FirstOrDefaultAsync(u => u.Nickname == nickname);
        
        if (user == null || user.SessionToken != sessionToken)
            throw new HubException("Сессия истекла");

        await FinalizeLogin(user, false);
    }

    private async Task FinalizeLogin(User user, bool generateNewToken)
    {
        if (!string.IsNullOrEmpty(user.ConnectionId) && user.ConnectionId != Context.ConnectionId)
            await Clients.Client(user.ConnectionId).SendAsync("ForceLogout", "Вы вошли с другого устройства");

        if (generateNewToken)
            user.SessionToken = Guid.NewGuid().ToString();

        user.ConnectionId = Context.ConnectionId;
        user.IsOnline = true;
        user.LastSeen = DateTime.UtcNow;
        await _db.SaveChangesAsync();

        string displayNick = user.Nickname.StartsWith('#') ? user.Nickname.Substring(1) : user.Nickname;
        await Clients.All.SendAsync("UserJoined", displayNick);
        
        // Отправляем закреплённое сообщение при входе
        var pinnedMessage = await _db.PinnedMessages.OrderByDescending(p => p.PinnedAt).FirstOrDefaultAsync();
        if (pinnedMessage != null)
        {
            var msg = await _db.Messages.FirstOrDefaultAsync(m => m.Id == pinnedMessage.MessageId);
            if (msg != null)
            {
                string userNick = msg.User.StartsWith('#') ? msg.User.Substring(1) : msg.User;
                var pinnedData = new Dictionary<string, object> {
                    ["Id"] = msg.Id,
                    ["Nickname"] = userNick,
                    ["Text"] = msg.IsDeleted ? "Сообщение удалено" : msg.Text,
                    ["FileUrl"] = msg.IsDeleted ? "" : (msg.FileUrl ?? ""),
                    ["FileType"] = msg.IsDeleted ? "" : (msg.FileType ?? ""),
                    ["Time"] = msg.Timestamp.ToLocalTime().ToString("HH:mm"),
                    ["IsAdmin"] = msg.User == "#Админ",
                    ["IsDeleted"] = msg.IsDeleted,
                    ["PinnedBy"] = pinnedMessage.PinnedBy,
                    ["PinnedAt"] = pinnedMessage.PinnedAt.ToLocalTime().ToString("dd.MM.yyyy HH:mm")
                };
                await Clients.Caller.SendAsync("PinnedMessage", pinnedData);
            }
        }
        
        var messages = await _db.Messages.OrderByDescending(m => m.Timestamp).Take(100).ToListAsync();
        messages.Reverse();
        var normalizedMessages = messages.Select(m => {
            string userNick = m.User.StartsWith('#') ? m.User.Substring(1) : m.User;
            return new Dictionary<string, object> {
                ["Id"] = m.Id,
                ["Nickname"] = userNick,
                ["Text"] = m.IsDeleted ? "Сообщение удалено" : m.Text,
                ["FileUrl"] = m.IsDeleted ? "" : (m.FileUrl ?? ""),
                ["FileType"] = m.IsDeleted ? "" : (m.FileType ?? ""),
                ["Time"] = m.Timestamp.ToLocalTime().ToString("HH:mm"),
                ["IsAdmin"] = m.User == "#Админ",
                ["IsDeleted"] = m.IsDeleted
            };
        }).ToList();
        await Clients.Caller.SendAsync("LoadHistory", normalizedMessages);
        
        var loginData = new Dictionary<string, object>
        {
            ["Nickname"] = displayNick,
            ["SessionToken"] = user.SessionToken,
            ["IsAdmin"] = user.IsAdmin
        };
        
        await Clients.Caller.SendAsync("LoginSuccess", loginData);
        await UpdateOnlineUsers();
    }

    public async Task SendMessage(string text)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.ConnectionId == Context.ConnectionId);
        if (user == null) return;

        // --- ОБРАБОТКА КОМАНД ---
        if (text == "/help") { await ShowHelp(); return; }
        if (text == "/ping") 
        { 
            await Clients.Caller.SendAsync("ReceiveMessage", new Dictionary<string, object> {
                ["Nickname"] = "Система", ["Text"] = $"🏓 Pong! {DateTime.Now:HH:mm:ss}",
                ["Time"] = DateTime.Now.ToString("HH:mm"), ["IsAdmin"] = false, ["IsDeleted"] = false
            });
            return; 
        }
        if (text.StartsWith("/search ")) 
        { 
            await SearchMessages(text.Substring(8));
            return; 
        }
        if (text.StartsWith("/pm ")) 
        {
            var parts = text.Substring(4).Split(new[] { ' ' }, 2);
            if (parts.Length < 2)
            {
                await Clients.Caller.SendAsync("ReceiveMessage", new Dictionary<string, object> {
                    ["Nickname"] = "Система", ["Text"] = "❌ Использование: /pm <ник> <сообщение>",
                    ["Time"] = DateTime.Now.ToString("HH:mm"), ["IsAdmin"] = false, ["IsDeleted"] = false
                });
                return;
            }
            await SendPrivateMessage(parts[0], parts[1]);
            return;
        }

        // Команды админа
        if (user.IsAdmin)
        { 
            if (text.StartsWith("/create ")) { await CreateUser(text); return; }
            if (text.StartsWith("/approve ")) { await ApproveUser(text); return; }
        }

        // --- ОБЫЧНОЕ СООБЩЕНИЕ ---
        var message = new ChatMessage { User = user.Nickname, Text = text, Timestamp = DateTime.UtcNow };
        _db.Messages.Add(message);
        await _db.SaveChangesAsync();

        string displayNick = user.Nickname.StartsWith('#') ? user.Nickname.Substring(1) : user.Nickname;
        var msgData = new Dictionary<string, object> {
            ["Id"] = message.Id,
            ["Nickname"] = displayNick,
            ["Text"] = text,
            ["FileUrl"] = "",
            ["FileType"] = "",
            ["Time"] = DateTime.Now.ToString("HH:mm"),
            ["IsAdmin"] = user.IsAdmin,
            ["IsDeleted"] = false
        };
        await Clients.All.SendAsync("ReceiveMessage", msgData);
    }

   public async Task PinMessage(int messageId)
{
    var user = await _db.Users.FirstOrDefaultAsync(u => u.ConnectionId == Context.ConnectionId);
    
    if (user == null)
    {
        _logger.LogWarning("PinMessage: Пользователь не найден");
        return;
    }

    var message = await _db.Messages.FirstOrDefaultAsync(m => m.Id == messageId);
    if (message == null)
    {
        await Clients.Caller.SendAsync("ReceiveMessage", new Dictionary<string, object> {
            ["Nickname"] = "Система",
            ["Text"] = "❌ Сообщение не найдено",
            ["Time"] = DateTime.Now.ToString("HH:mm"),
            ["IsAdmin"] = false,
            ["IsDeleted"] = false
        });
        return;
    }

    try
    {
        await using var transaction = await _db.Database.BeginTransactionAsync();
        
        // Удаляем СТАРОЕ закреплённое (если есть)
        var oldPinned = await _db.PinnedMessages.OrderByDescending(p => p.PinnedAt).FirstOrDefaultAsync();
        if (oldPinned != null)
        {
            var oldMsg = await _db.Messages.FirstOrDefaultAsync(m => m.Id == oldPinned.MessageId);
            if (oldMsg != null)
            {
                oldMsg.IsPinned = false;
            }
            _db.PinnedMessages.Remove(oldPinned);
            _logger.LogInformation($" Откреплено старое сообщение #{oldPinned.MessageId}");
        }

        // Закрепляем НОВОЕ
        _db.PinnedMessages.Add(new PinnedMessage {
            MessageId = messageId,
            PinnedBy = user.Nickname,
            PinnedAt = DateTime.UtcNow
        });
        message.IsPinned = true;
        
        await _db.SaveChangesAsync();
        await transaction.CommitAsync();
        _logger.LogInformation($"✅ [{user.Nickname}] закрепил сообщение #{messageId}");

        // Отправляем всем обновлённое закреплённое
        string displayNick = message.User.StartsWith('#') ? message.User.Substring(1) : message.User;
        string pinnedByNick = user.Nickname.StartsWith('#') ? user.Nickname.Substring(1) : user.Nickname;
        
        var pinnedData = new Dictionary<string, object> {
            ["Id"] = message.Id,
            ["Nickname"] = displayNick,
            ["Text"] = message.IsDeleted ? "Сообщение удалено" : message.Text,
            ["FileUrl"] = message.IsDeleted ? "" : (message.FileUrl ?? ""),
            ["FileType"] = message.IsDeleted ? "" : (message.FileType ?? ""),
            ["Time"] = message.Timestamp.ToLocalTime().ToString("HH:mm"),
            ["IsAdmin"] = message.User == "#Админ",
            ["IsDeleted"] = message.IsDeleted,
            ["PinnedBy"] = pinnedByNick,
            ["PinnedAt"] = DateTime.Now.ToLocalTime().ToString("dd.MM.yyyy HH:mm")
        };
        await Clients.All.SendAsync("PinnedMessage", pinnedData);
    }
    catch (Exception ex)
    {
        _logger.LogError(ex, $"❌ Ошибка при закреплении сообщения #{messageId}");
        await Clients.Caller.SendAsync("ReceiveMessage", new Dictionary<string, object> {
            ["Nickname"] = "Система",
            ["Text"] = "❌ Ошибка сервера при закреплении",
            ["Time"] = DateTime.Now.ToString("HH:mm"),
            ["IsAdmin"] = false,
            ["IsDeleted"] = false
        });
    }
}
    public async Task UnpinMessage()
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.ConnectionId == Context.ConnectionId);
        if (user == null || !user.IsAdmin) return;

        var pinned = await _db.PinnedMessages.OrderByDescending(p => p.PinnedAt).FirstOrDefaultAsync();
        if (pinned != null)
        {
            await using var transaction = await _db.Database.BeginTransactionAsync();
            try
            {
                var message = await _db.Messages.FirstOrDefaultAsync(m => m.Id == pinned.MessageId);
                if (message != null) message.IsPinned = false;
                
                _db.PinnedMessages.Remove(pinned);
                await _db.SaveChangesAsync();
                await transaction.CommitAsync();
                
                _logger.LogInformation($"✅ [{user.Nickname}] открепил сообщение");
                await Clients.All.SendAsync("MessageUnpinned");
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _logger.LogError(ex, "Ошибка при откреплении сообщения");
            }
        }
    }

    public async Task DeleteMessage(int messageId)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.ConnectionId == Context.ConnectionId);
        if (user == null) return;

        var message = await _db.Messages.FirstOrDefaultAsync(m => m.Id == messageId);
        if (message == null) return;

        if (message.User != user.Nickname && !user.IsAdmin)
        {
            await Clients.Caller.SendAsync("ReceiveMessage", new Dictionary<string, object> {
                ["Nickname"] = "Система", ["Text"] = "❌ Можно удалить только своё сообщение",
                ["Time"] = DateTime.Now.ToString("HH:mm"), ["IsAdmin"] = false, ["IsDeleted"] = false
            });
            return;
        }

        var pinned = await _db.PinnedMessages.FirstOrDefaultAsync(p => p.MessageId == messageId);
        if (pinned != null)
        {
            _db.PinnedMessages.Remove(pinned);
            message.IsPinned = false;
            await _db.SaveChangesAsync();
            await Clients.All.SendAsync("MessageUnpinned");
        }

        message.IsDeleted = true;
        message.Text = "";
        message.FileUrl = null;
        message.FileType = null;
        await _db.SaveChangesAsync();

        var msgData = new Dictionary<string, object> {
            ["Id"] = message.Id,
            ["Nickname"] = message.User.StartsWith('#') ? message.User.Substring(1) : message.User,
            ["Text"] = "Сообщение удалено",
            ["FileUrl"] = "",
            ["FileType"] = "",
            ["Time"] = message.Timestamp.ToLocalTime().ToString("HH:mm"),
            ["IsAdmin"] = message.User == "#Админ",
            ["IsDeleted"] = true
        };
        await Clients.All.SendAsync("MessageDeleted", msgData);
    }

    // --- НОВЫЕ МЕТОДЫ ---

    public async Task SearchMessages(string searchText)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.ConnectionId == Context.ConnectionId);
        if (user == null || string.IsNullOrWhiteSpace(searchText)) return;

        var messages = await _db.Messages
            .Where(m => m.Text.Contains(searchText) && !m.IsDeleted)
            .OrderByDescending(m => m.Timestamp)
            .Take(20)
            .ToListAsync();

        await Clients.Caller.SendAsync("ReceiveMessage", new Dictionary<string, object> {
            ["Nickname"] = "🔍 Поиск",
            ["Text"] = $"Найдено сообщений: {messages.Count} по запросу '{searchText}'",
            ["Time"] = DateTime.Now.ToString("HH:mm"),
            ["IsAdmin"] = false,
            ["IsDeleted"] = false
        });

        foreach (var msg in messages)
        {
            string userNick = msg.User.StartsWith('#') ? msg.User.Substring(1) : msg.User;
            await Clients.Caller.SendAsync("ReceiveMessage", new Dictionary<string, object> {
                ["Id"] = msg.Id,
                ["Nickname"] = userNick,
                ["Text"] = msg.Text,
                ["Time"] = msg.Timestamp.ToLocalTime().ToString("HH:mm"),
                ["IsAdmin"] = msg.User == "#Админ",
                ["IsDeleted"] = false,
                ["IsSearchResult"] = true
            });
        }
    }

    public async Task SendPrivateMessage(string receiverNickname, string text)
    {
        var sender = await _db.Users.FirstOrDefaultAsync(u => u.ConnectionId == Context.ConnectionId);
        if (sender == null) return;

        if (!receiverNickname.StartsWith('#')) receiverNickname = "#" + receiverNickname;
        var receiver = await _db.Users.FirstOrDefaultAsync(u => u.Nickname == receiverNickname);
        
        if (receiver == null)
        {
            await Clients.Caller.SendAsync("ReceiveMessage", new Dictionary<string, object> {
                ["Nickname"] = "Система", ["Text"] = $"❌ Пользователь {receiverNickname} не найден",
                ["Time"] = DateTime.Now.ToString("HH:mm"), ["IsAdmin"] = false, ["IsDeleted"] = false
            });
            return;
        }

        var pm = new PrivateMessage {
            SenderId = sender.Nickname,
            ReceiverId = receiver.Nickname,
            Text = text,
            Timestamp = DateTime.UtcNow,
            IsRead = false
        };
        _db.PrivateMessages.Add(pm);
        await _db.SaveChangesAsync();

        if (!string.IsNullOrEmpty(receiver.ConnectionId))
        {
            await Clients.Client(receiver.ConnectionId).SendAsync("ReceivePrivateMessage", 
                sender.Nickname.Substring(1), text, DateTime.Now.ToString("HH:mm"), pm.Id);
        }

        await Clients.Caller.SendAsync("ReceiveMessage", new Dictionary<string, object> {
            ["Nickname"] = "Система",
            ["Text"] = $"✉️ Личное сообщение отправлено пользователю {receiver.Nickname.Substring(1)}",
            ["Time"] = DateTime.Now.ToString("HH:mm"), ["IsAdmin"] = false, ["IsDeleted"] = false
        });
    }

    public async Task ShowHelp()
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.ConnectionId == Context.ConnectionId);
        if (user == null) return;

        string helpText = user.IsAdmin ? 
            "📋 Команды:\n/help - справка\n/search <текст> - поиск\n/pm <ник> <текст> - личное сообщение\n/create #Ник Пароль\n/approve #Ник" :
            "📋 Команды:\n/help - справка\n/search <текст> - поиск\n/pm <ник> <текст> - личное сообщение";

        await Clients.Caller.SendAsync("ReceiveMessage", new Dictionary<string, object> {
            ["Nickname"] = "🤖 Справка",
            ["Text"] = helpText,
            ["Time"] = DateTime.Now.ToString("HH:mm"),
            ["IsAdmin"] = false,
            ["IsDeleted"] = false
        });
    }

    // --- ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ---

    public async Task SendTyping(string nickname)
    {
        await Clients.Others.SendAsync("UserTyping", nickname);
    }

    private async Task CreateUser(string command)
    {
        var parts = command.Substring(8).Split(' ');
        if (parts.Length < 2) { await Clients.Caller.SendAsync("ReceiveMessage", new Dictionary<string, object> { ["Nickname"] = "Система", ["Text"] = "❌ Использование: /create #Ник Пароль", ["Time"] = DateTime.Now.ToString("HH:mm"), ["IsAdmin"] = false }); return; }
        var nick = parts[0].Trim(); if (!nick.StartsWith('#')) nick = "#" + nick;
        
        if (await _db.Users.AnyAsync(u => u.Nickname == nick)) {
            await Clients.Caller.SendAsync("ReceiveMessage", new Dictionary<string, object> { ["Nickname"] = "Система", ["Text"] = $"❌ {nick} уже существует", ["Time"] = DateTime.Now.ToString("HH:mm"), ["IsAdmin"] = false }); return; 
        }

        _db.Users.Add(new User { Nickname = nick, PasswordHash = BCrypt.Net.BCrypt.HashPassword(parts[1].Trim()), IsApproved = true, IsAdmin = false });
        await _db.SaveChangesAsync();
        await Clients.Caller.SendAsync("ReceiveMessage", new Dictionary<string, object> { ["Nickname"] = "Система", ["Text"] = $"✅ {nick} создан!", ["Time"] = DateTime.Now.ToString("HH:mm"), ["IsAdmin"] = false });
    }

    private async Task ApproveUser(string command)
    {
        var nick = command.Substring(9).Trim(); if (!nick.StartsWith('#')) nick = "#" + nick;
        var targetUser = await _db.Users.FirstOrDefaultAsync(u => u.Nickname == nick);
        if (targetUser != null) {
            targetUser.IsApproved = true; await _db.SaveChangesAsync();
            await Clients.Caller.SendAsync("ReceiveMessage", new Dictionary<string, object> { ["Nickname"] = "Система", ["Text"] = $"✅ {nick} одобрен!", ["Time"] = DateTime.Now.ToString("HH:mm"), ["IsAdmin"] = false });
        }
    }

    public async Task SendFile(string fileName, string fileUrl, string fileType)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.ConnectionId == Context.ConnectionId);
        if (user == null) return;

        var message = new ChatMessage { User = user.Nickname, Text = fileName, FileUrl = fileUrl, FileType = fileType, Timestamp = DateTime.UtcNow };
        _db.Messages.Add(message);
        await _db.SaveChangesAsync();

        string displayNick = user.Nickname.StartsWith('#') ? user.Nickname.Substring(1) : user.Nickname;
        await Clients.All.SendAsync("ReceiveMessage", new Dictionary<string, object> {
            ["Id"] = message.Id,
            ["Nickname"] = displayNick,
            ["Text"] = fileName,
            ["FileUrl"] = fileUrl,
            ["FileType"] = fileType,
            ["Time"] = DateTime.Now.ToString("HH:mm"),
            ["IsAdmin"] = user.IsAdmin,
            ["IsDeleted"] = false
        });
    }

    public override async Task OnDisconnectedAsync(Exception? exception)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.ConnectionId == Context.ConnectionId);
        if (user != null)
        {
            user.LastSeen = DateTime.UtcNow;
            user.ConnectionId = null;
            user.IsOnline = false;
            await _db.SaveChangesAsync();
            
            string displayNick = user.Nickname.StartsWith('#') ? user.Nickname.Substring(1) : user.Nickname;
            await Clients.All.SendAsync("UserLeft", displayNick);
            await UpdateOnlineUsers();
        }
        await base.OnDisconnectedAsync(exception);
    }

    private async Task UpdateOnlineUsers()
    {
        var onlineUsers = await _db.Users.Where(u => u.IsOnline).ToListAsync();
        var displayNames = onlineUsers.Select(u => u.Nickname.StartsWith('#') ? u.Nickname.Substring(1) : u.Nickname).ToList();
        await Clients.All.SendAsync("UpdateUsers", displayNames);
    }
}
